<?php
// Conectar a la base de datos
$conexion = mysqli_connect('localhost', 'root', '', 'esquema');

// Verificar si se recibió un tipo de búsqueda y un término de búsqueda
if (isset($_POST['tipo-busqueda']) && isset($_POST['termino-busqueda'])) {
  $tipoBusqueda = $_POST['tipo-busqueda'];
  $terminoBusqueda = $_POST['termino-busqueda'];

  // Escapar el término de búsqueda para evitar inyección SQL
  $terminoBusqueda = mysqli_real_escape_string($conexion, $terminoBusqueda);

  // Realizar la consulta para obtener los clientes que coincidan con el término de búsqueda
  $consulta = "SELECT id, Nombre, Genero, Profesion, Pais, fecha FROM tabla_clientes WHERE $tipoBusqueda LIKE '%$terminoBusqueda%'";
  $resultados = mysqli_query($conexion, $consulta);

  // Mostrar los resultados de la búsqueda en una tabla HTML
  echo '<table>';
  echo '<thead><tr><th>ID</th><th>Nombres</th><th>Género</th><th>Profesión</th><th>País</th><th>Fecha</th></tr></thead>';
  echo '<tbody>';
  while ($fila = mysqli_fetch_assoc($resultados)) {
    echo '<tr>';
    echo '<td>' . $fila['id'] . '</td>';
    echo '<td>' . $fila['Nombre'] . '</td>';
    echo '<td>' . $fila['Genero'] . '</td>';
    echo '<td>' . $fila['Profesion'] . '</td>';
    echo '<td>' . $fila['Pais'] . '</td>';
    echo '<td>' . $fila['fecha'] . '</td>';
    echo '</tr>';
  }
  echo '</tbody>';
  echo '</table>';
} else {
  // Si no se recibió un tipo de búsqueda y un término de búsqueda, mostrar un mensaje de error
  echo 'Debe proporcionar un tipo de búsqueda y un término de búsqueda.';
}

// Cerrar la conexión a la base de datos
mysqli_close($conexion);
