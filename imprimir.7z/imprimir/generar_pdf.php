<?php
// Importar la librería FPDF
require('fpdf/fpdf.php');
header('Content-Type: text/html; charset=UTF-8');
// Obtener el tipo de búsqueda y el término de búsqueda desde la solicitud GET
$tipoBusqueda = $_GET['tipo-busqueda'];
$terminoBusqueda = $_GET['termino-busqueda'];

// Conectar a la base de datos y realizar la búsqueda de clientes
$conexion = mysqli_connect('localhost', 'root', '', 'esquema');
$consulta = "SELECT * FROM tabla_clientes WHERE $tipoBusqueda LIKE '%$terminoBusqueda%'";
$resultados = mysqli_query($conexion, $consulta);

// Crear un nuevo documento PDF
$pdf = new FPDF();
$pdf->AddPage();
// Obtener el ancho de la página
$pageWidth = $pdf->GetPageWidth();

// Establecer la fuente y el tamaño de fuente para el texto
$pdf->SetFont('Arial', 'B', 16);

// Obtener el ancho de la página
$pageWidth = $pdf->GetPageWidth();

// Obtener el ancho y alto de la imagen
$imageWidth = 25;
$imageHeight = 25;

// Calcular la posición x e y para centrar la imagen
$imagePosX = ($pageWidth - $imageWidth) / 2;
$imagePosY = 30;

// Agregar la imagen centrada
$pdf->Image('logo.png', $imagePosX, $imagePosY, $imageWidth, $imageHeight);

// Calcular la posición x para centrar el texto
$textPosX = ($pageWidth - $pdf->GetStringWidth('Resultados de la busqueda')) / 2;

// Establecer la posición y para imprimir el texto debajo de la imagen
$textPosY = $imagePosY + $imageHeight + 10;

// Imprimir el texto centrado debajo de la imagen
$pdf->SetXY($textPosX, $textPosY);

$pdf->Cell(40, 10, 'SENA-CTGI');
$pdf->Ln();
$pdf->Ln();
$pdf->SetFont('Arial', '', 12);
$pdf->Cell(40, 10, 'EJEMPLO DE BUSQUEDA  => ' . $tipoBusqueda);
$pdf->Ln();
$pdf->Cell(40, 10, 'VERSION FUNCIONA SIN CARACTERES PHP 8 >=' . $terminoBusqueda);
$pdf->Ln();
$pdf->Ln();
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(20, 10, 'ID');
$pdf->Cell(40, 10, 'Nombre');
$pdf->Cell(20, 10, 'Genero');
$pdf->Cell(40, 10, 'Profesion');
$pdf->Cell(40, 10, 'Pais');
$pdf->Cell(30, 10, 'Fecha');
$pdf->Ln();
$pdf->SetFont('Arial', '', 12);
while ($fila = mysqli_fetch_assoc($resultados)) {
  $pdf->Cell(20, 10, $fila['id']);
  $pdf->Cell(40, 10, $fila['Nombre']);
  $pdf->Cell(20, 10, $fila['Genero']);
  $pdf->Cell(40, 10, $fila['Profesion']);
  $pdf->Cell(40, 10, $fila['Pais']);
  $pdf->Cell(30, 10, $fila['fecha']);
  $pdf->Ln();
}

// Cerrar la conexión a la base de datos y generar el archivo PDF
mysqli_close($conexion);
$pdf->Output();